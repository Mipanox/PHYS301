fruitPrices = {'apples' : 2.00,
               'oranges': 1.50,
               'pears'  : 1.75, 
               'limes'  : 0.75,
               'strawberries': 1.00,
               'bananas'     : 0.79, # new fruits
               'applepears'  : 1.24}

def buyLotsOfFruit(orderList):
    """
        orderList: List of (fruit, numPounds) tuples
            
    Returns cost of order
    """
    cost = 0.
    for (fruit,num) in orderList:
        try: 
            cost += fruitPrices[fruit] * num
        except:
            print('This fruit not in list!')
            return None
    return cost
