from matplotlib import pylab as plt
import math

x = plt.randn(10000)
plt.plot(x,plt.sin(x/50*math.pi),'b-', x,plt.cos(x/50*math.pi),'r--')
plt.legend( ('sin','cos') )

plt.savefig('trip.png')
