import numpy as np
x = np.array([1,  5, -2, 6, 8, 10])
y = np.array([-1, 0,  1, 1, 2,  3])

a = np.dot(x,y)

z1 = np.copy(x)
z1[x<0] = 0

z2 = x[y>0]

z3 = np.sum(y[x%2==0])
