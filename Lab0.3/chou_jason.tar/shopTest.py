import shop

name = 'Physics 100'
fruitPrices = {'apples':2.00, 'oranges': 1.50, 'pears': 1.75}
myFruitShop = shop.FruitShop(name, fruitPrices)
print myFruitShop.getCostPerPound('apples')

otherName = 'Physics 301'
otherFruitPrices = {'kiwis':1.00, 'bananas': 1.50, 'peaches': 2.75}
otherFruitShop = shop.FruitShop(otherName, otherFruitPrices)
print otherFruitShop.getCostPerPound('bananas')
