wordlist = ['LaTeX', 'Hello World', 'ok', 'lowercase', 'UPPERCASE', 'Hi']
print [word.lower() for word in wordlist if len(word) > 5]
