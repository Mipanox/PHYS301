from matplotlib import pylab as plt

x = plt.randn(10000)
plt.hist(x,100)
plt.savefig('histogram.png')
